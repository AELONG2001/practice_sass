const iconMenu =  $('.box-icon')
const boxNav =  $('.box-nav')

iconMenu.addEventListener('click', () => {
    boxNav.classList.toggle('active');
})
